package com.mona.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.mona.assistant.ai.GeminiRepository
import com.mona.assistant.ai.MessageEngine
import com.mona.assistant.ai.MonaIntent
import com.mona.assistant.services.MonaAccessibilityService
import com.mona.assistant.services.MonaNotificationListenerService
import com.mona.assistant.services.MonaTTSManager
import com.mona.assistant.ui.VisualizerView
import com.mona.assistant.utils.PrefsManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

/**
 * Mona's HUD screen. Owns the SpeechRecognizer (ear), MonaTTSManager (voice), and
 * GeminiRepository (brain) and wires them together:
 *   mic tap -> transcript -> Gemini classifies intent -> execute action or speak reply.
 *
 * Also listens for MonaNotificationListenerService callbacks so incoming WhatsApp/SMS
 * messages get read aloud even while this screen is open.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var visualizer: VisualizerView
    private lateinit var statusText: TextView
    private lateinit var transcriptText: TextView
    private lateinit var tts: MonaTTSManager
    private lateinit var speechRecognizer: SpeechRecognizer

    private var geminiRepository: GeminiRepository? = null
    private var pendingAutoReplyIntent: MonaIntent? = null // awaiting "yes, send it" confirmation

    private val micPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startListening() else toast("Mona needs microphone access to hear you")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        visualizer = findViewById(R.id.visualizer)
        statusText = findViewById(R.id.statusText)
        transcriptText = findViewById(R.id.transcriptText)

        tts = MonaTTSManager(
            context = this,
            onStart = { runOnUiThread { visualizer.state = VisualizerView.State.SPEAKING } },
            onDone = { runOnUiThread { visualizer.state = VisualizerView.State.IDLE } }
        )

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)

        findViewById<android.view.View>(R.id.settingsButton).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        visualizer.setOnClickListener { requestMicAndListen() }

        if (!PrefsManager.hasApiKey()) {
            statusText.text = "Set your Gemini API key in Settings first"
        } else {
            geminiRepository = GeminiRepository(PrefsManager.getApiKey())
            tts.speak(getString(R.string.greeting).replace("Boss", PrefsManager.getUserName()))
        }

        // Real-time incoming-message narration, wired to the NotificationListenerService.
        MonaNotificationListenerService.listener = { sender, body, _ ->
            runOnUiThread { handleIncomingMessage(sender, body) }
        }
    }

    override fun onDestroy() {
        speechRecognizer.destroy()
        tts.shutdown()
        MonaNotificationListenerService.listener = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------------------------
    // Listening
    // ---------------------------------------------------------------------------------

    private fun requestMicAndListen() {
        if (PrefsManager.getApiKey().isBlank()) {
            toast("Add your Gemini API key in Settings first")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun startListening() {
        visualizer.state = VisualizerView.State.LISTENING
        statusText.text = "Listening..."

        // RecognizerIntent.LANGUAGE_MODEL_FREE_FORM + no fixed EXTRA_LANGUAGE lets Android's
        // recognizer auto-detect among the device's configured input languages; combined with
        // Gemini's own language detection downstream, this gives Mona broad multilingual reach.
        val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, Locale.getDefault().toString())
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
        }

        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) = visualizer.onMicRms(rmsdB)
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { visualizer.state = VisualizerView.State.THINKING }
            override fun onError(error: Int) {
                visualizer.state = VisualizerView.State.IDLE
                statusText.text = getString(R.string.tap_to_speak)
            }

            override fun onResults(results: Bundle?) {
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                if (text.isNullOrBlank()) {
                    visualizer.state = VisualizerView.State.IDLE
                } else {
                    transcriptText.text = text
                    handleTranscript(text)
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        speechRecognizer.startListening(recognizerIntent)
    }

    // ---------------------------------------------------------------------------------
    // Sending the transcript to Gemini and acting on the result
    // ---------------------------------------------------------------------------------

    private fun handleTranscript(transcript: String) {
        val repo = geminiRepository ?: return
        visualizer.state = VisualizerView.State.THINKING
        statusText.text = "Thinking..."

        // Simple confirm-to-send flow: if we're awaiting "yes/send it" for a drafted auto-reply.
        if (pendingAutoReplyIntent != null && isAffirmative(transcript)) {
            confirmPendingSend()
            return
        }

        lifecycleScope.launch {
            val intent = try {
                withContext(Dispatchers.IO) {
                    repo.interpret(transcript, PrefsManager.getUserName())
                }
            } catch (e: Exception) {
                speakAndReset("Sorry, I ran into a problem reaching Gemini: ${e.message}")
                return@launch
            }
            executeIntent(intent)
        }
    }

    private fun executeIntent(intent: MonaIntent) {
        val locale = try { Locale.forLanguageTag(intent.detectedLanguage) } catch (e: Exception) { Locale.getDefault() }
        val accessibility = MonaAccessibilityService.instance

        when (intent.action) {
            "CHAT_REPLY" -> speak(intent.spokenReply, locale)

            "OPEN_APP" -> {
                val opened = accessibility?.openApp(intent.target ?: "") ?: false
                speak(if (opened) intent.spokenReply else "I couldn't find that app.", locale)
            }
            "CLOSE_APP" -> { accessibility?.closeCurrentApp(); speak(intent.spokenReply, locale) }
            "GO_BACK" -> { accessibility?.goBack(); speak(intent.spokenReply, locale) }
            "GO_HOME" -> { accessibility?.goHome(); speak(intent.spokenReply, locale) }
            "SCROLL" -> {
                accessibility?.scroll(forward = intent.target != "up")
                speak(intent.spokenReply, locale)
            }
            "TOGGLE_WIFI" -> { accessibility?.toggleWifi(enable = intent.target != "off"); speak(intent.spokenReply, locale) }
            "TOGGLE_BLUETOOTH" -> { accessibility?.toggleBluetooth(enable = intent.target != "off"); speak(intent.spokenReply, locale) }
            "TOGGLE_FLASHLIGHT" -> { accessibility?.toggleFlashlight(on = intent.target != "off"); speak(intent.spokenReply, locale) }
            "SET_VOLUME" -> { accessibility?.setVolume(intent.target?.toIntOrNull() ?: 50); speak(intent.spokenReply, locale) }
            "SET_BRIGHTNESS" -> { accessibility?.setBrightness(intent.target?.toIntOrNull() ?: 50); speak(intent.spokenReply, locale) }

            "SEND_MESSAGE_DICTATED", "SEND_MESSAGE_AUTO" -> {
                if (accessibility == null) {
                    speak("Please enable Mona's Accessibility Service in Settings first.", locale)
                    return
                }
                lifecycleScope.launch(Dispatchers.IO) {
                    val result = MessageEngine(accessibility).execute(intent)
                    withContext(Dispatchers.Main) { handleMessageResult(result, intent, locale) }
                }
            }

            else -> speak(intent.spokenReply, locale)
        }
    }

    private fun handleMessageResult(result: MessageEngine.Result, intent: MonaIntent, locale: Locale) {
        when (result) {
            is MessageEngine.Result.Success -> speak("Message sent to ${intent.target}.", locale)
            is MessageEngine.Result.NeedsConfirmation -> {
                pendingAutoReplyIntent = intent
                speak("I've drafted: \"${result.draftedText}\". Should I send it?", locale)
            }
            is MessageEngine.Result.Failure -> speak("I couldn't send that: ${result.reason}", locale)
        }
    }

    private fun confirmPendingSend() {
        val accessibility = MonaAccessibilityService.instance
        val intent = pendingAutoReplyIntent
        pendingAutoReplyIntent = null
        if (accessibility == null || intent == null) return

        lifecycleScope.launch(Dispatchers.IO) {
            val result = MessageEngine(accessibility).confirmAndSend()
            withContext(Dispatchers.Main) {
                when (result) {
                    is MessageEngine.Result.Success -> speak("Sent.", Locale.getDefault())
                    is MessageEngine.Result.Failure -> speak("Couldn't send it: ${result.reason}", Locale.getDefault())
                    else -> {}
                }
            }
        }
    }

    private fun isAffirmative(text: String): Boolean =
        Regex("\\b(yes|yeah|send it|haan|ha bhej do|si|oui)\\b", RegexOption.IGNORE_CASE).containsMatchIn(text)

    // ---------------------------------------------------------------------------------
    // Incoming message narration (NotificationListenerService callback)
    // ---------------------------------------------------------------------------------

    private fun handleIncomingMessage(sender: String, body: String) {
        val repo = geminiRepository ?: return
        lifecycleScope.launch {
            val spoken = try {
                withContext(Dispatchers.IO) { repo.describeIncomingMessage(sender, body) }
            } catch (e: Exception) {
                "New message from $sender."
            }
            speak(spoken, Locale.getDefault())
        }
    }

    // ---------------------------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------------------------

    private fun speak(text: String, locale: Locale) {
        statusText.text = getString(R.string.tap_to_speak)
        transcriptText.text = text
        tts.speak(text, locale)
    }

    private fun speakAndReset(text: String) {
        visualizer.state = VisualizerView.State.IDLE
        speak(text, Locale.getDefault())
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
