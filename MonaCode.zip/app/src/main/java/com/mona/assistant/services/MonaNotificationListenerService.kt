package com.mona.assistant.services

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Intercepts incoming notifications system-wide so Mona can read messages (WhatsApp, SMS,
 * Telegram, etc.) aloud in real time, and — combined with GeminiRepository + the Accessibility
 * Service — draft/send replies on the user's behalf.
 *
 * Only a small allow-list of known messaging packages is surfaced by default so Mona doesn't
 * narrate every email/game/system notification; extend MESSAGING_PACKAGES as needed.
 */
class MonaNotificationListenerService : NotificationListenerService() {

    companion object {
        private val MESSAGING_PACKAGES = setOf(
            "com.whatsapp",
            "com.whatsapp.w4b",
            "com.google.android.apps.messaging", // Google Messages (SMS)
            "org.telegram.messenger",
            "com.instagram.android",
            "com.facebook.orca" // Messenger
        )

        /** Simple in-process callback hook — MainActivity registers itself to receive events. */
        var listener: ((sender: String, body: String, packageName: String) -> Unit)? = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName !in MESSAGING_PACKAGES) return

        val extras = sbn.notification.extras
        val sender = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: "Someone"
        val body = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return

        // Group/message-style notifications sometimes nest the real text in EXTRA_MESSAGES;
        // fall back to that if the top-level text looks like a generic summary.
        val resolvedBody = extractLatestLineIfMessagingStyle(extras) ?: body

        listener?.invoke(sender, resolvedBody, sbn.packageName)
    }

    private fun extractLatestLineIfMessagingStyle(extras: android.os.Bundle): String? {
        val messages = extras.getParcelableArray(Notification.EXTRA_MESSAGES) ?: return null
        val last = messages.lastOrNull() as? android.os.Bundle ?: return null
        return last.getCharSequence("text")?.toString()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        // No-op: Mona doesn't need to react to dismissed notifications.
    }
}
