package com.mona.assistant

import android.app.Application
import com.mona.assistant.utils.PrefsManager

class MonaApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Initialize encrypted prefs once, app-wide, so every screen/service can read
        // the API key and user name without re-touching the Keystore each time.
        PrefsManager.init(this)
    }
}
