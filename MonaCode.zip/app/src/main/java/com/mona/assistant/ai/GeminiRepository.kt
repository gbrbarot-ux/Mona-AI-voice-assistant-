package com.mona.assistant.ai

import org.json.JSONObject

/**
 * Represents what Mona decided to do with a spoken command, after Gemini classified it.
 * MainActivity/MonaAccessibilityService switch on [action] to actually carry it out.
 */
data class MonaIntent(
    val action: String,              // e.g. "OPEN_APP", "TOGGLE_WIFI", "SEND_MESSAGE", "CHAT_REPLY"
    val target: String? = null,      // e.g. app name, contact name, setting name
    val messageText: String? = null, // dictated or drafted message body
    val spokenReply: String,         // what Mona should say out loud in the user's language
    val detectedLanguage: String     // BCP-47 tag, e.g. "hi-IN", "es-ES", used to pick TTS voice
)

/**
 * High-level brain of the assistant. Every raw transcript from the SpeechRecognizer passes
 * through here. Gemini is asked to (1) detect language, (2) classify the user's intent against
 * a fixed action vocabulary Mona's Accessibility/Notification services know how to execute, and
 * (3) draft the natural-language reply Mona will speak — all in ONE call, returned as JSON, so
 * the round trip stays fast enough for a voice UI.
 */
class GeminiRepository(apiKey: String) {

    private val client = GeminiClient(apiKey)

    private val systemInstruction = """
        You are Mona, a warm, capable, multilingual personal voice assistant.
        You ALWAYS detect the language/dialect the user just spoke in and reply fluently in
        that same language — never switch to English unless the user spoke English.
        You address the user by the name given to you in the prompt.

        You must respond with ONLY a JSON object, no prose outside it, matching this schema:
        {
          "action": one of ["OPEN_APP","CLOSE_APP","TOGGLE_WIFI","TOGGLE_BLUETOOTH",
                             "SET_VOLUME","SET_BRIGHTNESS","TOGGLE_FLASHLIGHT","SCROLL",
                             "GO_BACK","GO_HOME","SEND_MESSAGE_DICTATED","SEND_MESSAGE_AUTO",
                             "READ_NOTIFICATION","CHAT_REPLY"],
          "target": string or null (app name, contact name, setting name, scroll direction),
          "messageText": string or null (only for the SEND_MESSAGE_* actions),
          "spokenReply": string (what you say out loud, in the user's detected language),
          "detectedLanguage": string (BCP-47 tag, e.g. "en-US", "hi-IN", "es-ES", "ja-JP")
        }

        Rules:
        - If the user just wants to talk / asks a question with no device action implied,
          use action "CHAT_REPLY" and put your full answer in spokenReply.
        - "Mere hisab se message karo" / "type exactly what I say" style phrasing means
          SEND_MESSAGE_DICTATED: messageText is the literal text to send, unedited.
        - "Apne hisab se reply kar do" / "reply for me" / "you decide" style phrasing means
          SEND_MESSAGE_AUTO: you compose messageText yourself, using any incoming-message
          context supplied in the prompt, in the SAME language as that incoming message.
        - Keep spokenReply concise (1-2 sentences) — it will be spoken aloud, not read.
    """.trimIndent()

    /**
     * @param transcript what the user just said (already speech-to-text'd by Android).
     * @param userName how Mona should address the user (default "Boss").
     * @param incomingMessageContext optional text of a message Mona is being asked to reply to,
     *        used only for SEND_MESSAGE_AUTO requests.
     */
    fun interpret(
        transcript: String,
        userName: String,
        incomingMessageContext: String? = null
    ): MonaIntent {
        val prompt = buildString {
            appendLine("User's name to address them by: $userName")
            if (!incomingMessageContext.isNullOrBlank()) {
                appendLine("Incoming message Mona may need to reply to: \"$incomingMessageContext\"")
            }
            appendLine("User said: \"$transcript\"")
        }

        val rawJson = client.generate(systemInstruction, prompt, forceJson = true)
        val json = JSONObject(rawJson)

        return MonaIntent(
            action = json.optString("action", "CHAT_REPLY"),
            target = json.optString("target", null).takeUnless { it == "null" },
            messageText = json.optString("messageText", null).takeUnless { it == "null" },
            spokenReply = json.optString("spokenReply", "Sorry, I didn't catch that."),
            detectedLanguage = json.optString("detectedLanguage", "en-US")
        )
    }

    /**
     * Used by MonaNotificationListenerService for the "read this message aloud, then let me
     * decide dictated vs autonomous reply" flow — a lighter call that just summarizes/translates
     * an incoming notification into something natural to speak.
     */
    fun describeIncomingMessage(sender: String, body: String): String {
        val prompt = "New message from $sender: \"$body\". " +
            "In ONE natural spoken sentence, in the SAME language as the message, tell the " +
            "user who it's from and what it says, suitable for text-to-speech (no JSON, plain text)."
        return client.generate(
            systemInstruction = "You are Mona, a voice assistant. Reply with plain spoken text only.",
            userText = prompt,
            forceJson = false
        ).trim()
    }
}
