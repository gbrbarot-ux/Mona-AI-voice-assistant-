package com.mona.assistant.ai

import com.mona.assistant.services.MonaAccessibilityService

/**
 * Bridges a MonaIntent (SEND_MESSAGE_DICTATED / SEND_MESSAGE_AUTO) to real taps/typing via
 * the Accessibility Service. This is intentionally conservative: it opens the target app,
 * finds the named contact, types into the compose box, and — for autonomous replies —
 * waits for the caller to confirm before actually pressing Send (see [autoSendWithoutConfirm]).
 *
 * NOTE: Exact element labels ("Search", "Send", the contact row layout) are approximations
 * for WhatsApp's current UI. Messaging apps change their UI often; if a step fails, log which
 * clickByText() call returned false and adjust the label to match the current app version —
 * see the implementation guide's "Keeping automation working" section.
 */
class MessageEngine(private val accessibility: MonaAccessibilityService) {

    sealed class Result {
        data class Success(val sentText: String) : Result()
        data class NeedsConfirmation(val draftedText: String) : Result()
        data class Failure(val reason: String) : Result()
    }

    /**
     * Executes a SEND_MESSAGE_DICTATED or SEND_MESSAGE_AUTO intent.
     * @param autoSendWithoutConfirm if false (recommended default for AUTO mode), the message
     *        is typed but NOT sent — MainActivity should ask "Should I send this?" and call
     *        [confirmAndSend] only after the user says yes.
     */
    fun execute(intent: MonaIntent, autoSendWithoutConfirm: Boolean = false): Result {
        val contact = intent.target ?: return Result.Failure("No contact specified")
        val text = intent.messageText ?: return Result.Failure("No message text to send")

        if (!accessibility.openApp("WhatsApp")) {
            return Result.Failure("Could not open WhatsApp")
        }

        // Give the app a moment to render before searching — a real implementation should
        // poll rootInActiveWindow instead of a fixed sleep; simplified here for clarity.
        Thread.sleep(1200)

        if (!accessibility.clickByText("Search")) return Result.Failure("Search icon not found")
        Thread.sleep(400)
        if (!accessibility.typeIntoFocusedField(contact)) return Result.Failure("Could not type contact name")
        Thread.sleep(700)
        if (!accessibility.clickByText(contact)) return Result.Failure("Contact '$contact' not found")
        Thread.sleep(700)

        if (!accessibility.typeIntoFocusedField(text)) return Result.Failure("Could not type message")

        val isAuto = intent.action == "SEND_MESSAGE_AUTO"
        if (isAuto && !autoSendWithoutConfirm) {
            // Leave it typed but unsent; caller/UI should confirm with the user first.
            return Result.NeedsConfirmation(text)
        }

        return if (accessibility.clickByText("Send")) {
            Result.Success(text)
        } else {
            Result.Failure("Send button not found")
        }
    }

    /** Called after the user verbally confirms an autonomous draft ("yes, send it"). */
    fun confirmAndSend(): Result {
        return if (accessibility.clickByText("Send")) {
            Result.Success("(confirmed draft)")
        } else {
            Result.Failure("Send button not found")
        }
    }
}
