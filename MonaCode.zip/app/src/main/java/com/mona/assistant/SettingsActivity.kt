package com.mona.assistant

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.mona.assistant.utils.PrefsManager

/**
 * Lets the user paste their own Gemini API key (stored encrypted, never hardcoded/shipped
 * with the app) and pick what name Mona calls them (defaults to "Boss"). Also deep-links to
 * the two system permission screens Mona needs: Accessibility and Notification access.
 */
class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val apiKeyInput = findViewById<EditText>(R.id.apiKeyInput)
        val userNameInput = findViewById<EditText>(R.id.userNameInput)

        apiKeyInput.setText(PrefsManager.getApiKey())
        userNameInput.setText(PrefsManager.getUserName())

        findViewById<Button>(R.id.saveButton).setOnClickListener {
            val key = apiKeyInput.text.toString().trim()
            val name = userNameInput.text.toString().trim().ifBlank { "Boss" }

            if (key.isBlank()) {
                Toast.makeText(this, "Please enter a Gemini API key", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            PrefsManager.saveApiKey(key)
            PrefsManager.saveUserName(name)
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            finish()
        }

        // Android has no API to grant Accessibility/Notification access programmatically —
        // the user must flip these on manually in system Settings; we just deep-link there.
        findViewById<Button>(R.id.openAccessibilityButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.openNotificationAccessButton).setOnClickListener {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }
    }
}
