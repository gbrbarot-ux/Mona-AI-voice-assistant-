package com.mona.assistant.utils

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Wraps EncryptedSharedPreferences so the Gemini API key is never stored in plain text
 * on disk. Also holds the lightweight user-facing settings (name Mona uses to address you).
 */
object PrefsManager {

    private const val FILE_NAME = "mona_secure_prefs"
    private const val KEY_GEMINI_API_KEY = "gemini_api_key"
    private const val KEY_USER_NAME = "user_name"
    private const val DEFAULT_USER_NAME = "Boss"

    private lateinit var prefs: SharedPreferences

    fun init(context: Context) {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        prefs = EncryptedSharedPreferences.create(
            context,
            FILE_NAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun saveApiKey(key: String) = prefs.edit().putString(KEY_GEMINI_API_KEY, key).apply()

    fun getApiKey(): String = prefs.getString(KEY_GEMINI_API_KEY, "") ?: ""

    fun saveUserName(name: String) = prefs.edit().putString(KEY_USER_NAME, name).apply()

    fun getUserName(): String = prefs.getString(KEY_USER_NAME, DEFAULT_USER_NAME) ?: DEFAULT_USER_NAME

    fun hasApiKey(): Boolean = getApiKey().isNotBlank()
}
