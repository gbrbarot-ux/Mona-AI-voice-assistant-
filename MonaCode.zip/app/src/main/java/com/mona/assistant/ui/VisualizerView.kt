package com.mona.assistant.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.min
import kotlin.random.Random

/**
 * Custom-drawn HUD circle that visually communicates Mona's state:
 *  - IDLE:      slow gentle pulse, dim cyan
 *  - LISTENING: fast reactive pulse driven by mic amplitude, bright cyan/purple rings
 *  - THINKING:  rotating gradient arc (processing spinner look)
 *  - SPEAKING:  waveform-like bar pulses radiating outward, pink/purple
 *
 * No external animation libraries are used; everything is driven by a single
 * ValueAnimator that repeatedly invalidates the view.
 */
class VisualizerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    enum class State { IDLE, LISTENING, THINKING, SPEAKING }

    var state: State = State.IDLE
        set(value) {
            field = value
            phase = 0f
        }

    /** Feed 0f..1f mic amplitude here while LISTENING for a reactive pulse. */
    var amplitude: Float = 0f

    private var phase = 0f
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }

    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1600
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = (phase + 0.012f) % 1f
            invalidate()
        }
    }

    init {
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val base = min(width, height) / 2f * 0.55f

        val (colorA, colorB, pulse) = when (state) {
            State.IDLE -> Triple(Color.parseColor("#1AE5FF"), Color.parseColor("#0A0E17"),
                base * (1f + 0.04f * kotlin.math.sin(phase * 2 * Math.PI).toFloat()))
            State.LISTENING -> Triple(Color.parseColor("#00E5FF"), Color.parseColor("#7C4DFF"),
                base * (1f + 0.25f * amplitude))
            State.THINKING -> Triple(Color.parseColor("#7C4DFF"), Color.parseColor("#00E5FF"),
                base * (1f + 0.06f * kotlin.math.sin(phase * 4 * Math.PI).toFloat()))
            State.SPEAKING -> Triple(Color.parseColor("#FF4DA6"), Color.parseColor("#7C4DFF"),
                base * (1f + 0.18f * kotlin.math.abs(kotlin.math.sin(phase * 8 * Math.PI)).toFloat()))
        }

        // Glowing core
        corePaint.shader = RadialGradient(cx, cy, pulse, colorA, colorB, Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, pulse, corePaint)

        // Outer rings: number and spacing depend on state, giving each mode a distinct "signature"
        val ringCount = if (state == State.LISTENING || state == State.SPEAKING) 3 else 2
        for (i in 1..ringCount) {
            val ringPhase = (phase + i / ringCount.toFloat()) % 1f
            val radius = pulse + ringPhase * base * 0.9f
            ringPaint.color = colorA
            ringPaint.alpha = ((1f - ringPhase) * 160).toInt().coerceIn(0, 255)
            canvas.drawCircle(cx, cy, radius, ringPaint)
        }
    }

    /** Call from the recognizer's RMS callback to make the LISTENING state reactive. */
    fun onMicRms(rms: Float) {
        // SpeechRecognizer RMS is roughly -2..10 dB; normalize to 0..1 with light smoothing.
        val normalized = ((rms + 2f) / 12f).coerceIn(0f, 1f)
        amplitude = amplitude * 0.6f + normalized * 0.4f
    }

    /** Simple decorative jitter used while THINKING if you don't have a real amplitude source. */
    fun randomJitter(): Float = Random.nextFloat() * 0.1f
}
