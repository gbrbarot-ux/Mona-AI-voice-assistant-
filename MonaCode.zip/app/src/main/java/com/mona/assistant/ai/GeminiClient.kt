package com.mona.assistant.ai

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Thin REST wrapper around the Gemini "generateContent" endpoint.
 * No official Kotlin SDK is required — Gemini's HTTP API is plain JSON over HTTPS,
 * so this uses OkHttp directly to keep the dependency footprint small.
 *
 * Model name is intentionally a constructor parameter, NOT hardcoded deep in the code —
 * Google periodically renames/retires models, so check
 * https://ai.google.dev/gemini-api/docs/models for the current recommended flash model
 * before shipping.
 */
class GeminiClient(
    private val apiKey: String,
    private val model: String = "gemini-2.0-flash"
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val endpoint: String
        get() = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"

    /**
     * Sends [systemInstruction] + [userText] and returns the raw text of Gemini's reply.
     * [forceJson] wraps the request so Gemini's response is guaranteed valid JSON — used by
     * GeminiRepository when it needs a structured intent (action + parameters) rather than
     * free-form conversational text.
     */
    fun generate(systemInstruction: String, userText: String, forceJson: Boolean = false): String {
        val body = JSONObject().apply {
            put("system_instruction", JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text", systemInstruction)))
            })
            put("contents", JSONArray().put(
                JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put("text", userText)))
                }
            ))
            if (forceJson) {
                put("generationConfig", JSONObject().put("response_mime_type", "application/json"))
            }
        }

        val request = Request.Builder()
            .url(endpoint)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw GeminiException("Gemini API error ${response.code}: $raw")
            }
            val json = JSONObject(raw)
            return json.getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")
        }
    }
}

class GeminiException(message: String) : Exception(message)
