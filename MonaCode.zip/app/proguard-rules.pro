# Add project specific ProGuard rules here.
-keep class com.mona.assistant.** { *; }
