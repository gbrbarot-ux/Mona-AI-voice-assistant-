# Mona — Implementation & Build Guide

This project is a working scaffold for "Mona," an all-in-one Kotlin voice assistant with a
HUD-style UI, Gemini-powered multilingual understanding, deep system control via an
Accessibility Service, and message reading/sending via a Notification Listener.

## 1. What's included

```
Mona/
├── build.gradle.kts / settings.gradle.kts / gradle.properties
├── local.properties.example        (rename to local.properties, set your SDK path)
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/mona/assistant/
        │   ├── MonaApplication.kt          init encrypted prefs
        │   ├── MainActivity.kt             HUD screen, mic → Gemini → action pipeline
        │   ├── SettingsActivity.kt         API key + user name + permission deep-links
        │   ├── ai/
        │   │   ├── GeminiClient.kt         raw REST call to generateContent
        │   │   ├── GeminiRepository.kt     system prompt, intent schema, language detection
        │   │   └── MessageEngine.kt        turns a SEND_MESSAGE_* intent into taps/typing
        │   ├── services/
        │   │   ├── MonaAccessibilityService.kt   app control, clicks, scroll, toggles
        │   │   ├── MonaNotificationListenerService.kt  reads WhatsApp/SMS notifications
        │   │   └── MonaTTSManager.kt        female-voice TTS wrapper
        │   ├── ui/VisualizerView.kt         animated HUD circle (idle/listening/thinking/speaking)
        │   └── utils/PrefsManager.kt        EncryptedSharedPreferences wrapper
        └── res/  (layouts, colors, theme, launcher icon, accessibility_service_config.xml)
```

This is a functioning **architecture and core implementation**, not a polished commercial
product — treat it as the skeleton you build on, test against real devices, and harden.

## 2. Opening the project

1. Install **Android Studio Koala (2024.1.1) or newer**.
2. Unzip the project, then in Android Studio: **File → Open** → select the `Mona/` folder.
3. Copy `local.properties.example` to `local.properties` and set `sdk.dir` to your local
   Android SDK path (Android Studio usually creates this automatically on first sync).
4. Let Gradle sync. It will download AGP 8.5.2, Kotlin 1.9.24, and the dependencies listed in
   `app/build.gradle.kts` (OkHttp, org.json, AndroidX security-crypto, coroutines, etc.).
5. minSdk is **26** (Android 8.0) — required for reliable `AccessibilityNodeInfo.ACTION_SET_TEXT`
   and adaptive icons. Test devices/emulators should run API 26+.

## 3. Getting a Gemini API key

1. Go to **https://aistudio.google.com/app/apikey** and create a key (free tier available).
2. Run the app, tap the settings icon (top-right gear), paste the key, and set your name
   (defaults to "Boss"). It's stored via `EncryptedSharedPreferences` — never hardcode a key
   into source control.
3. `GeminiClient` defaults to the `gemini-2.0-flash` model. Google renames/retires models
   periodically — check **https://ai.google.dev/gemini-api/docs/models** if you get a 404.

## 4. Granting the two special permissions

Android does not let apps silently enable these — the user must flip them on manually, and
Settings has buttons that deep-link there:

- **Accessibility Service** (`Settings → Enable Accessibility Service` button, or
  Android Settings → Accessibility → Mona → On). This is what lets `MonaAccessibilityService`
  open apps, tap buttons, scroll, and toggle Wi‑Fi/Bluetooth/flashlight.
- **Notification Access** (`Settings → Enable Notification Access` button, or Android
  Settings → Apps → Special access → Notification access → Mona → On). This is what lets
  `MonaNotificationListenerService` see incoming WhatsApp/SMS notifications to read aloud.
- **Microphone** is requested normally at runtime (standard `RECORD_AUDIO` prompt) the first
  time you tap the HUD circle.
- **Modify system settings** (for brightness control) and **Camera** (for flashlight) are
  requested/deep-linked from `MonaAccessibilityService` the first time they're needed.

Without Accessibility + Notification access, Mona still works as a **conversational**
assistant (chat, Q&A, translation) via `CHAT_REPLY`, but can't control the device or read/send
messages.

## 5. Female voice / TTS setup

`MonaTTSManager` asks the active TTS engine for a voice matching the reply's language whose
name signals "female," with a heuristic fallback for engines that don't label gender.

For the best multilingual, natural-sounding results:
1. On the test device, go to **Settings → System → Languages & input → Text-to-speech output**.
2. Set the preferred engine to **"Speech Services by Google"** (install/update it from Play
   Store if not present) — it has the widest set of high-quality neural female voices across
   languages (Hindi, Spanish, Japanese, Arabic, etc.).
3. Under that engine's settings, install the language packs you want Mona to speak fluently.

Voice naming conventions differ by engine version, so treat `looksFemaleByHeuristic()` in
`MonaTTSManager.kt` as a starting point — log `tts.voices` on your target device and refine
the matching rule for the exact engine/version you ship with.

## 6. How the "brain" pipeline works

1. User taps the HUD circle → `SpeechRecognizer` transcribes speech (Android's built-in
   on-device/cloud recognizer, language auto-preference from the device locale).
2. The transcript is sent to `GeminiRepository.interpret()`, which asks Gemini to return
   **one JSON object**: detected language, a classified `action` from a fixed vocabulary, any
   `target`/`messageText`, and a natural-language `spokenReply` — all in a single API round trip.
3. `MainActivity.executeIntent()` switches on `action`:
   - `CHAT_REPLY` → just speaks the reply (this is how "translate/answer in any language" works).
   - `OPEN_APP` / `TOGGLE_WIFI` / `SCROLL` / etc. → calls the matching method on
     `MonaAccessibilityService.instance`.
   - `SEND_MESSAGE_DICTATED` / `SEND_MESSAGE_AUTO` → handed to `MessageEngine`, which drives
     the Accessibility Service to open WhatsApp, find the contact, type the text, and (for
     dictated mode) send immediately, or (for autonomous mode) **wait for a spoken "yes, send
     it" confirmation** before pressing Send — a safety default you can change via
     `autoSendWithoutConfirm` in `MessageEngine.execute()`.
4. Incoming messages: `MonaNotificationListenerService` fires a callback into `MainActivity`,
   which asks Gemini to turn "sender + body" into one natural spoken sentence
   (`describeIncomingMessage`) and speaks it — in whatever language the message was written in.

## 7. Keeping the messaging automation working

`MessageEngine.execute()` locates on-screen elements by **visible text** ("Search", "Send", the
contact's name). This is the same technique tools like Tasker/AutoNotification use, but it is
inherently fragile:

- WhatsApp/Messages UI text and layout changes across app versions and locales (the "Search"
  icon has no text label on some versions — you may need `contentDescription` matching instead,
  which `findNodeByText()` already checks).
- Add logging around each `clickByText()`/`typeIntoFocusedField()` call during testing; when a
  step returns `false`, dump `rootInActiveWindow` (Android Studio's **Layout Inspector**, or
  `adb shell uiautomator dump`) to see the current element tree and adjust the target label.
- Consider adding short `View.postDelayed` polling instead of the fixed `Thread.sleep()` calls
  used here for clarity, so taps wait for the UI to actually finish rendering rather than a
  guessed delay.

## 8. Play Store policy notes (read before publishing)

- **Accessibility Service**: Google requires the app's *core function* to genuinely need it —
  a voice assistant that acts on your behalf qualifies, but you must clearly disclose this in
  your Play Console "Accessibility" declaration and in-app, and the
  `accessibility_service_description` string (already in `strings.xml`) is shown to users when
  they enable it — keep it accurate.
- **Notification access**: also requires a Play Console disclosure form describing exactly why
  the app reads notifications.
- **Automating third-party apps** (typing/sending inside WhatsApp) can conflict with that
  app's own Terms of Service even though it's technically just accessibility automation on the
  user's own device with their permission — review WhatsApp's ToS if you plan wide distribution,
  and consider gating this feature as opt-in/advanced.
- None of the above blocks building and running this for personal/sideloaded use — the review
  requirements mainly apply to public Play Store distribution.

## 9. Building the APK

**Debug APK (for your own device, no signing needed):**
```
./gradlew assembleDebug
```
Output: `app/build/outputs/apk/debug/app-debug.apk` — install with
`adb install app/build/outputs/apk/debug/app-debug.apk`, or drag it onto an emulator.

**Release APK (signed, for wider distribution):**
1. Generate a keystore once: `keytool -genkeypair -v -keystore mona-release.keystore -alias mona -keyalg RSA -keysize 2048 -validity 10000`
2. In `app/build.gradle.kts`, add a `signingConfigs { release { ... } }` block referencing that
   keystore (Android Studio's **Build → Generate Signed Bundle/APK** wizard can do this for you
   interactively instead of hand-editing Gradle).
3. Run `./gradlew assembleRelease`; output lands in `app/build/outputs/apk/release/`.

## 10. Suggested next steps

- Replace the fixed `Thread.sleep()` waits in `MessageEngine` with proper UI-ready polling.
- Add a wake-word ("Hey Mona") using an always-listening foreground service if you want
  hands-free activation instead of tap-to-speak (note: this needs a persistent foreground
  service + notification, and meaningfully increases battery use).
- Persist conversation context across turns (currently each Gemini call is stateless) if you
  want Mona to handle multi-turn follow-ups like "no, the other one."
- Expand `MonaNotificationListenerService.MESSAGING_PACKAGES` and `MessageEngine`'s target app
  name for other chat apps beyond WhatsApp.
