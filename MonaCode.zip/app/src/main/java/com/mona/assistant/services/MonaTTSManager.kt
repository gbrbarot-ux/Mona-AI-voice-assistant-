package com.mona.assistant.services

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import java.util.Locale
import java.util.UUID

/**
 * Wraps Android's TextToSpeech engine and biases voice selection toward a natural-sounding
 * FEMALE voice, in whatever language the text is written in (so Mona can reply in Hindi,
 * Spanish, Japanese, etc. and still sound like "a girl" rather than falling back to a
 * generic/default voice).
 *
 * Voice availability differs by device/OS version and installed TTS engine (Google's
 * "Speech Services by Google" has the widest, best-quality multilingual female voice set,
 * so the implementation guide tells users to install/enable it).
 */
class MonaTTSManager(
    context: Context,
    private val onStart: () -> Unit = {},
    private val onDone: () -> Unit = {}
) {
    private var tts: TextToSpeech? = null
    private var ready = false
    private val pendingQueue = mutableListOf<String>()

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ready = true
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) = onStart()
                    override fun onDone(utteranceId: String?) = onDone()
                    override fun onError(utteranceId: String?) = onDone()
                })
                selectFemaleVoice(Locale.getDefault())
                pendingQueue.forEach { speakInternal(it) }
                pendingQueue.clear()
            }
        }
    }

    /** Re-picks the best female voice whenever Mona needs to switch spoken language. */
    private fun selectFemaleVoice(locale: Locale) {
        val engine = tts ?: return
        val available: Set<Voice> = try { engine.voices ?: emptySet() } catch (e: Exception) { emptySet() }

        val femaleCandidate = available
            .filter { it.locale.language == locale.language && !it.isNetworkConnectionRequired }
            .filter { v -> v.name.contains("female", ignoreCase = true) || looksFemaleByHeuristic(v) }
            .minByOrNull { it.latency }

        if (femaleCandidate != null) {
            engine.voice = femaleCandidate
        } else {
            // Fall back: just match the language/locale and let the engine pick its default.
            engine.language = locale
        }
    }

    /**
     * Many engines don't label gender explicitly in the Voice name. As a heuristic fallback,
     * common Google "Speech Services" female voice variants use these suffix conventions.
     * This is best-effort — always prefer an explicit "female" match above first.
     */
    private fun looksFemaleByHeuristic(voice: Voice): Boolean {
        val n = voice.name.lowercase()
        return n.endsWith("-a") || n.endsWith("-c") || n.contains("wavenet-a") || n.contains("wavenet-c")
    }

    /**
     * Speaks [text]. Detects the dominant script/language of the text with a very light
     * heuristic and switches voice/locale before speaking, so replies in Hindi, Arabic,
     * Japanese, etc. don't come out in an English voice reading transliterated gibberish.
     */
    fun speak(text: String, detectedLocale: Locale? = null) {
        if (!ready) {
            pendingQueue.add(text)
            return
        }
        detectedLocale?.let { selectFemaleVoice(it) }
        speakInternal(text)
    }

    private fun speakInternal(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, UUID.randomUUID().toString())
    }

    fun stop() = tts?.stop()

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}
