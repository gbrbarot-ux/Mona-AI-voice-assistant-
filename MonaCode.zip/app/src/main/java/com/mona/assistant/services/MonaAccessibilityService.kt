package com.mona.assistant.services

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

/**
 * The hands of Mona. Once the user grants Accessibility permission, this service can:
 *  - Launch/close apps by name
 *  - Find and click on-screen elements by their visible text
 *  - Scroll, go back, go home
 *  - Toggle Wi-Fi, Bluetooth, flashlight, and change volume/brightness
 *  - Type text into whatever input field currently has focus (used by the messaging engine
 *    to actually fill in WhatsApp/SMS compose boxes before tapping Send)
 *
 * IMPORTANT: Google Play restricts Accessibility Service usage to apps whose *primary*
 * function needs it (this one qualifies — it's the core of a voice-controlled assistant).
 * See the implementation guide's "Play Store policy" section before publishing.
 */
class MonaAccessibilityService : AccessibilityService() {

    companion object {
        // Simple static reference so MainActivity/GeminiRepository callers can drive the
        // service without binding — acceptable for a single-process personal assistant app.
        var instance: MonaAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    // Accessibility events stream in constantly; Mona doesn't need to react to all of them,
    // only to the ones the command-execution methods below explicitly wait on.
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    // ---------------------------------------------------------------------------------
    // App launching / closing
    // ---------------------------------------------------------------------------------

    /** Opens an app by its human-readable label, e.g. "WhatsApp", "Chrome". */
    fun openApp(appLabel: String): Boolean {
        val pm = packageManager
        val launchIntent = pm.getInstalledApplications(0).firstOrNull { appInfo ->
            pm.getApplicationLabel(appInfo).toString().equals(appLabel, ignoreCase = true)
        }?.let { pm.getLaunchIntentForPackage(it.packageName) }

        return if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launchIntent)
            true
        } else {
            false
        }
    }

    /** "Closing" an app on Android means going home / removing it from the foreground. */
    fun closeCurrentApp() {
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    fun goBack() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun goHome() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun openRecents() = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun openQuickSettings() = performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)

    // ---------------------------------------------------------------------------------
    // Finding & clicking on-screen elements
    // ---------------------------------------------------------------------------------

    /** Searches the current window for a node whose visible text/description contains [text]. */
    private fun findNodeByText(text: String): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        return findRecursive(root, text)
    }

    private fun findRecursive(node: AccessibilityNodeInfo, text: String): AccessibilityNodeInfo? {
        val nodeText = node.text?.toString() ?: node.contentDescription?.toString()
        if (nodeText?.contains(text, ignoreCase = true) == true) return node
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                findRecursive(child, text)?.let { return it }
            }
        }
        return null
    }

    /** Clicks the first on-screen element whose text matches [label]. Returns success. */
    fun clickByText(label: String): Boolean {
        val node = findNodeByText(label) ?: return false
        return performClickClimbingToClickable(node)
    }

    /** Accessibility nodes for icons/text are often non-clickable; climb to a clickable ancestor. */
    private fun performClickClimbingToClickable(start: AccessibilityNodeInfo): Boolean {
        var node: AccessibilityNodeInfo? = start
        while (node != null) {
            if (node.isClickable) return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            node = node.parent
        }
        return false
    }

    /**
     * Types [text] into the currently focused editable field (e.g. a WhatsApp/SMS compose box)
     * using ACTION_SET_TEXT. Used by the messaging engine after clickByText locates the field.
     */
    fun typeIntoFocusedField(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = findFocusedEditable(root) ?: return false
        val arguments = android.os.Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
    }

    private fun findFocusedEditable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isEditable && node.isFocused) return node
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                findFocusedEditable(child)?.let { return it }
            }
        }
        return null
    }

    /** Scrolls the first scrollable container found, forward or backward. */
    fun scroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val scrollable = findScrollable(root) ?: return false
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                     else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return scrollable.performAction(action)
    }

    private fun findScrollable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                findScrollable(child)?.let { return it }
            }
        }
        return null
    }

    /** Low-level swipe gesture, used as a fallback where ACTION_SCROLL isn't supported. */
    fun swipeUp() {
        val path = Path().apply {
            moveTo(500f, 1400f)
            lineTo(500f, 400f)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 300))
            .build()
        dispatchGesture(gesture, null, null)
    }

    // ---------------------------------------------------------------------------------
    // System settings toggles
    // ---------------------------------------------------------------------------------

    @Suppress("DEPRECATION")
    fun toggleWifi(enable: Boolean) {
        // WifiManager.setWifiEnabled() is deprecated/blocked for apps targeting Android 10+;
        // the reliable cross-version approach is to open the quick-toggle panel for the user.
        try {
            val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            wifiManager.isWifiEnabled = enable
        } catch (e: SecurityException) {
            startActivity(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    fun toggleBluetooth(enable: Boolean) {
        val adapter = BluetoothAdapter.getDefaultAdapter()
        try {
            if (enable) adapter?.enable() else adapter?.disable()
        } catch (e: SecurityException) {
            startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    fun setVolume(percent: Int) {
        val audioManager = applicationContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val level = (max * (percent.coerceIn(0, 100) / 100f)).toInt()
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, level, 0)
    }

    fun setBrightness(percent: Int) {
        if (!Settings.System.canWrite(applicationContext)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, android.net.Uri.parse("package:$packageName"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            Toast.makeText(this, "Please allow Mona to modify system settings", Toast.LENGTH_LONG).show()
            return
        }
        val level = (255 * (percent.coerceIn(0, 100) / 100f)).toInt()
        Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, level)
    }

    fun toggleFlashlight(on: Boolean) {
        val cameraManager = applicationContext.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        try {
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return
            cameraManager.setTorchMode(cameraId, on)
        } catch (e: Exception) {
            // Torch can throw if the camera is in use elsewhere; silently ignore per call site's UX.
        }
    }
}
